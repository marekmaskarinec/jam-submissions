Thanks for downloading :]

To install the game, run the install.sh script. If you don't want to install the game, you can run the wrapinvaders binary with `debug` flag.
Enjoy!
