To setup the game run the install.bat command. If you have installed the windows terminal, it will automatically open. When you have the terminal open, use the `cd` command to get into this directory.
For example: if this directory is Downloads/wrapinvaders, you will use cd Downloads\wrapinvaders. When you are in the directory, use .\wrapinvaders.exe to launch the game. If you have any questions, you
can ask me in itch comments or on my discord Marek Maškarinec#5526. Enjoy!
