# vaultjam2
My submission to [the 2nd Vaultacular Game Jam](https://itch.io/jam/a-vaultacular-game-jam). It is made in [umka](https://github.com/vtereshkov) using the [tophat](https://github.com/marekmaskarinec/tophat) engine.

## TODO

- make sure the first screen isn't a village
- tutorial
- sounds
- more biomes
- more content in forests
- ui

## build and run instructions

### 1. with tophat tool
If you have the tophat tool installed, just cd into the directory/open it as a workspace and use the run option. You can package it the same way.

## 2. with the tophat binary
Get yourself the tophat binary and the run it with the `debug` flag in the same directory as this game.
